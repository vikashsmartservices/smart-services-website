SMART SERVICES WEBSITE
=======================

Files:
- index.html
- style.css

How to use:
1. Keep index.html and style.css in the same folder.
2. Open index.html in a browser to preview the website.
3. Upload both files to your web hosting public_html folder.

The Call and WhatsApp buttons are configured with:
7070086544
9504646664

Business address:
70 Feet, Saristabad, Patna

You can replace text/images later without changing the overall design.
